# Independent blind annotation handoff

Assignment: `negative-reviewer-199ccb8d89c9d456`
Role: `reviewer`
Annotator: `annotator_02`
Frozen Git commit: `83b4f7662d60cacd1c6d099588892b8579790550`

1. Clone the repository and check out the exact frozen commit above.
2. Run the local review app against the extracted `tasks` directory.
3. Do not obtain or inspect the other annotator's labels.
4. After every case is human-attested and valid, seal the workspace:

```powershell
python scripts/annotation/manage_offline_handoff.py seal `
  --workspace <this-directory> `
  --output reviewer_completed.zip
```

Send the ZIP normally. Send the printed submission SHA-256 through a separate
trusted channel so the origin can detect transport substitution.
